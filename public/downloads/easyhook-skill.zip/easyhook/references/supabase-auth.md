# Supabase Auth through Easyhook

Easyhook installs Supabase's Send SMS Hook from **Portal > Integrations >
Supabase Auth**. Application code continues to use Supabase Auth; it does not
call an Easyhook messaging endpoint and must not contain an Easyhook API key.

## Configure the project

Choose one delivery policy in Easyhook:

- `sms`: requires an active Easyhook number with outbound SMS.
- `whatsapp`: requires a connected WhatsApp number and an approved,
  synchronized `AUTHENTICATION` template.
- `whatsapp_then_sms`: tries that WhatsApp template first and uses the selected
  SMS number only if the WhatsApp request fails.

An approved authentication template is Easyhook's eligibility signal. Meta may
require business verification before allowing the template to be created, but
do not infer a separate verification state after Meta has approved it.

## Application code

Request the code with the regular Supabase client. Include a CAPTCHA token when
the Supabase project enables CAPTCHA:

```ts
const { error } = await supabase.auth.signInWithOtp({
  phone: "+525566006997",
  options: { captchaToken }
})
```

Verify every phone OTP with Supabase's `sms` verification type, including codes
transported over WhatsApp:

```ts
const { data, error } = await supabase.auth.verifyOtp({
  phone: "+525566006997",
  token: code,
  type: "sms"
})
```

Do not use `options.channel` as an Easyhook transport selector. Supabase does
not include that field in the custom hook payload, so the Easyhook policy is
fixed per connected Supabase project. Supporting an explicit SMS/WhatsApp
choice for each end user requires a separate application-owned selection layer;
do not pretend the standard hook provides it.

Phone sign-in and phone MFA share the same project delivery policy. Easyhook
never writes the OTP to Inbox, customer webhooks, or integration records.
