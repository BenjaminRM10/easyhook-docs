# Supabase Auth through Easyhook

Easyhook installs Supabase's Send SMS Hook from **Portal > Integrations >
Supabase Auth**. Application code continues to use Supabase Auth; it does not
call an Easyhook messaging endpoint and must not contain an Easyhook API key.

## Installation model

Easyhook is intentionally absent from Supabase's native phone-provider list.
The portal uses Supabase Management OAuth to enable Phone Auth and install an
official signed HTTPS Send SMS Hook for the selected project. Do not instruct a
user to choose Twilio, Vonage, or another placeholder, and do not put an
Easyhook API key in Supabase or in the application. **Verificar** confirms that
Phone Auth and the project-specific hook are still active.

## Configure the project

Choose one delivery policy in Easyhook:

- `sms`: requires an active Easyhook number with outbound SMS.
- `whatsapp`: requires a connected WhatsApp number and an approved,
  synchronized `AUTHENTICATION` template.
- `whatsapp_then_sms`: tries that WhatsApp template first and uses the selected
  SMS number only if the WhatsApp request fails.

An approved authentication template is Easyhook's eligibility signal. Meta may
require business verification before allowing the template to be created, but
do not infer a separate verification state after Meta has approved it.

For SMS delivery, the integration locale accepts `es`, `en`, or `pt-BR` and
controls the Easyhook-generated OTP message. It does not change a WhatsApp
template's own Meta language code.

## Application code

Request the code with the regular Supabase client. Include a CAPTCHA token when
the Supabase project enables CAPTCHA:

```ts
const { error } = await supabase.auth.signInWithOtp({
  phone: "+15550100003",
  options: { captchaToken }
})
```

Verify every phone OTP with Supabase's `sms` verification type, including codes
transported over WhatsApp:

```ts
const { data, error } = await supabase.auth.verifyOtp({
  phone: "+15550100003",
  token: code,
  type: "sms"
})
```

Do not use `options.channel` as an Easyhook transport selector. Supabase does
not include that field in the custom hook payload, so the Easyhook policy is
fixed per connected Supabase project. Supporting an explicit SMS/WhatsApp
choice for each end user requires a separate application-owned selection layer;
do not pretend the standard hook provides it.

Phone sign-in and phone MFA share the same project delivery policy. Easyhook
never writes the OTP to Inbox, customer webhooks, or integration records.

Use the same E.164 phone for requesting and verifying the code. `type: "sms"`
remains correct even when WhatsApp delivered it. A successful `/otp` request
only confirms that Supabase accepted the hook result; the flow completes when
`verifyOtp` returns a session.

## Terminal test and diagnostics

Use the project URL and publishable key, never a service-role or secret key:

```bash
curl -sS -X POST "$SUPABASE_URL/auth/v1/otp" \
  -H "apikey: $SUPABASE_PUBLISHABLE_KEY" \
  -H "Content-Type: application/json" \
  --data "$(jq -nc --arg phone "$PHONE" '{phone:$phone}')"

VERIFY_RESPONSE=$(curl -sS -X POST "$SUPABASE_URL/auth/v1/verify" \
  -H "apikey: $SUPABASE_PUBLISHABLE_KEY" \
  -H "Content-Type: application/json" \
  --data "$(jq -nc --arg phone "$PHONE" --arg token "$OTP" \
    '{type:"sms",phone:$phone,token:$token}')")

printf '%s' "$VERIFY_RESPONSE" | jq '{
  authenticated: (.access_token != null),
  user_id: .user.id,
  phone: .user.phone,
  error_code,
  msg
}'

unset VERIFY_RESPONSE OTP
```

Do not print successful verification responses in shared logs because they
contain session tokens. Interpret common failures at the correct boundary:

- `captcha_failed`: Supabase rejected the request before invoking Easyhook.
- `phone_provider_disabled`: Phone Auth or the custom hook is not active; use
  **Verificar** in Easyhook rather than choosing an unrelated native provider.
- `Invalid payload sent to hook`: preserve Supabase's `error_id` and inspect
  the Easyhook hook/delivery result; do not retry blindly.
- `otp_expired`: delivery may already have succeeded. Use only the newest code,
  the exact same phone, and the configured validity window. Supabase commonly
  defaults to 60 seconds; 300 seconds is more practical for a controlled manual
  test.
- HTTP `429`: wait for the resend/rate-limit interval before requesting again.
