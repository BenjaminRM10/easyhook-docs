# Easyhook API

Base URL: `https://api.easyhook.dev`

Authenticate with:

```http
Authorization: Bearer eh_live_xxx
Content-Type: application/json
```

The key fixes the organization. The `from` value selects a channel owned by
that organization. Prefer the exact provider-native `account.id` received in a
webhook. Do not add `page_` or `ig_`. WhatsApp accepts its Meta Phone Number ID
or connected business phone number.

## Common Operations

| Goal | Method and path |
| --- | --- |
| Validate key | `GET /v1/me` |
| List canonical senders | `GET /v1/senders` |
| Send text | `POST /v1/messages/text` |
| Send humanized text | `POST /v1/messages/humanized-text` |
| Send reply | `POST /v1/messages/reply` |
| Send media | `POST /v1/messages/media` |
| Send/reply email | `POST /v1/messages/email` |
| Forward email | `POST /v1/messages/email/forward` |
| Update email state | `POST /v1/email/actions` |
| Create/update/send drafts | `/v1/email/drafts` |
| Send template | `POST /v1/messages/template` |
| List templates | `GET /v1/templates` |
| Check template category | `POST /v1/templates/classify` |
| Create and submit template | `POST /v1/templates` |
| Add/remove reaction | `POST /v1/messages/reaction` |
| Mark read | `POST /v1/messages/read` |
| Typing indicator | `POST /v1/messages/typing` |
| Create onboarding URL | `POST /v1/onboarding/sessions` |
| Create and send onboarding URL | `POST /v1/onboarding/sessions/send` |
| Send opt-in/out Flow | `POST /v1/consent` |
| Manage webhooks | `/v1/webhooks` |
| Upload/list organization media | `POST/GET /v1/media` |
| Download protected media | `GET /v1/media/{id}/download` |
| Get scheduled send | `GET /v1/scheduled-messages/{id}` |
| Cancel scheduled send | `DELETE /v1/scheduled-messages/{id}` |

## Text

```json
{
  "from": "980912725115744",
  "to": "5215660069997",
  "body": "Hola"
}
```

## Contextual Reply

```json
{
  "from": "980912725115744",
  "to": "5215660069997",
  "message_id": "wamid.original",
  "body": "Respuesta"
}
```

## Onboarding

Set `provider` to `whatsapp`, `messenger`, `instagram`, `telegram`, `gmail`,
`outlook`, `imap_smtp`, or `mercadolibre`. For WhatsApp, also choose
`signup_mode: "coexistence"` or `"cloud_api"`. Sessions expire in at most one
hour and are consumed after successful completion. The send endpoint always
sends a localized WhatsApp message containing the generated URL; custom message
bodies are rejected so the link cannot be omitted.

## WhatsApp Templates

Use `POST /v1/templates/classify` before creation for fast, non-blocking
category advice. The response can recommend `MARKETING`, `UTILITY`, or
`AUTHENTICATION`, but Meta makes the final classification decision.
`POST /v1/templates` always submits the requested template and includes the
same `category_advice` warning in its response; a warning does not block
submission.

## Consent

`POST /v1/consent` with `mode: "opt_in"` or `"opt_out"` sends the published
consent Flow. Consent must be enabled for the WABA. A response with
`accepted: true`, `delivery_status: "pending"`, and `wamid` means Meta accepted
the request; subscribe to `status.*` for delivery outcome.

To record consent collected by a website or CRM, omit `mode` and send
`scope`, `status`, `source`, and non-empty `evidence`. Opt-in evidence is
required. Easyhook stores the record but does not certify policy compliance.

## Provider Controls

| Provider | Read | Typing | Reply | Reaction | Humanized |
| --- | --- | --- | --- | --- | --- |
| WhatsApp | yes | yes | yes | yes | yes |
| Messenger | yes | yes | yes | no | yes |
| Instagram | yes | yes | yes | no | yes |
| Telegram | no | yes | yes | yes | yes |

Unsupported operations return HTTP `422 operation_not_supported` and are not
billed.

## Scheduling

Set `at` to an ISO 8601 date at least 30 seconds in the future. Text and media
are supported for WhatsApp, Messenger, Instagram, and Telegram. Mercado Libre
supports text. Use an `Idempotency-Key` header when retrying creation of the
same scheduled send. Email scheduling is not currently supported.

## Reusable And Incoming Media

Upload reusable media without `from`; names are unique inside the organization.
List it with `GET /v1/media`, then use `media_name` with any compatible sender.

Webhook `message.media.url` values are private. Download the exact URL
server-side with an API key from the same organization:

```bash
curl -L "$MESSAGE_MEDIA_URL" \
  -H "Authorization: Bearer $EASYHOOK_API_KEY" \
  --output received-media
```

For a customer portal, keep the API key in the backend and stream or proxy the
bytes only after authorizing the signed-in user. Never expose an Easyhook API
key in browser JavaScript. In n8n use `Media > Download`, map the URL, and keep
the default binary output field `data` unless the workflow needs another name.

## n8n Resources

| Resource | Purpose |
| --- | --- |
| Message Action | Cross-channel text and media sends |
| Message Control | Read, typing, contextual reply, and reaction |
| Email Only | Gmail, Outlook, and IMAP/SMTP actions |
| Onboarding | Create or send a hosted connection URL for any supported channel |
| WhatsApp Only | Templates, Flows, and consent |
| Template | List, synchronize, classify, create, and delete templates |
| Media | Organization uploads, listings, deletion, and authenticated downloads |

See the complete parameter and error tables at
`https://docs.easyhook.dev/api-reference`.
