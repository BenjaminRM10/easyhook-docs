# Easyhook API

Base URL: `https://api.easyhook.dev`

Authenticate with:

```http
Authorization: Bearer eh_live_xxx
Content-Type: application/json
```

The key fixes the organization. The `from` value selects a channel owned by
that organization.

## Common Operations

| Goal | Method and path |
| --- | --- |
| Validate key | `GET /v1/me` |
| Send text | `POST /v1/messages/text` |
| Send reply | `POST /v1/messages/reply` |
| Send media | `POST /v1/messages/media` |
| Send template | `POST /v1/messages/template` |
| Add/remove reaction | `POST /v1/messages/reaction` |
| Mark read | `POST /v1/messages/read` |
| Typing indicator | `POST /v1/messages/typing` |
| Create onboarding URL | `POST /v1/onboarding/sessions` |
| Create and send onboarding URL | `POST /v1/onboarding/sessions/send` |
| Send opt-in/out Flow | `POST /v1/consent` |
| Manage webhooks | `/v1/webhooks` |

## Text

```json
{
  "from": "5218661479075",
  "to": "5215660069997",
  "body": "Hola"
}
```

## Contextual Reply

```json
{
  "from": "5218661479075",
  "to": "5215660069997",
  "message_id": "wamid.original",
  "body": "Respuesta"
}
```

## Onboarding

Choose `signup_mode: "coexistence"` or `"cloud_api"`. Sessions expire in at
most one hour and are consumed after successful completion. The send endpoint
always sends a localized message containing the generated URL; custom message
bodies are rejected so the link cannot be omitted.

## Consent

`POST /v1/consent` with `mode: "opt_in"` or `"opt_out"` sends the published
consent Flow. Consent must be enabled for the WABA. A response with
`accepted: true`, `delivery_status: "pending"`, and `wamid` means Meta accepted
the request; subscribe to `status.*` for delivery outcome.

See the complete parameter and error tables at
`https://docs.easyhook.dev/api-reference`.
