# Easyhook Webhooks

Create subscriptions with `POST /v1/webhooks`. Discover provider, scope, and
event options through `GET /v1/webhooks/options`.

`providers` and `events` are explicit selections and neither can be empty.
Select provider `*` alone for every provider. Select event `*` alone when every
event is intended; do not combine it with concrete events. Easyhook rejects
events that are incompatible with the selected provider. Use the exact option
values returned by the options endpoint in the portal, API, and n8n.

## Security

Use HMAC authentication. Validate `X-Easyhook-Signature` against the exact raw
HTTP body with the subscription secret. Use constant-time comparison.

## Processing

- Delivery is at-least-once.
- Deduplicate messages by `message.id`.
- Deduplicate non-message events by top-level `id`.
- `message.direction` is `in` or `out`.
- `message.*` contains live inbound traffic only. It does not contain History
  imports or WhatsApp Business App echoes.
- `message.quick_reply` contains Messenger and Instagram quick-reply choices.
  Route by `message.quick_reply.payload`; keep `message.text` as the visible
  label.
- `smb_message_echo.*` contains outbound messages sent from WhatsApp Business
  App.
- `status.*` carries sent, delivered, read, and failed outcomes.
- `consent.updated` carries service or marketing opt-in/opt-out changes. Use
  top-level `id` for idempotency; evidence is intentionally omitted.
- `review.created` and `review.updated` carry normalized Google Business
  Profile reviews. Use top-level `id` for delivery idempotency and `review.id`
  to update the same review in application storage.
- Optional blocks may be omitted.
- Ignore unknown fields and future event types safely.

## History

History can arrive as `type: "sync.batch"` with up to 100 normalized events in
`events`. Iterate every event. Upsert by `message.id`, preserve
`message.timestamp`, and never auto-reply to `message.source: "history"`.

`message.media_available` updates the existing historical message with the same
ID. It is not a new message.

Subscribe to both `history.*` and `smb_app_state_sync.*` before a Coexistence
history import.

## Google Business Profile Reviews

Select provider `google_business_profile` and subscribe to `review.created`
and/or `review.updated`.

```json
{
  "id": "delivery-id",
  "type": "review.created",
  "provider": "google_business_profile",
  "account": {
    "id": "accounts/123/locations/456",
    "name": "Easyhook Monterrey"
  },
  "review": {
    "id": "review_abc",
    "name": "accounts/123/locations/456/reviews/review_abc",
    "rating": 5,
    "comment": "Excelente servicio",
    "reviewer": {
      "name": "Cliente",
      "photo_url": null,
      "is_anonymous": false
    },
    "created_at": "2026-08-04T12:00:00.000Z",
    "updated_at": "2026-08-04T12:00:00.000Z",
    "reply": null
  }
}
```

Google notifications identify the changed review; Easyhook fetches the current
review before delivering this normalized event. Treat `review.updated` as an
upsert, since the rating, comment, or public reply may have changed.

See schemas, retry behavior, scope rules, and examples at
`https://docs.easyhook.dev/webhooks`.
