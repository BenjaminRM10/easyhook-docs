# Easyhook Webhooks

Create subscriptions with `POST /v1/webhooks`. Discover provider, scope, and
event options through `GET /v1/webhooks/options`.

## Security

Use HMAC authentication. Validate `X-Easyhook-Signature` against the exact raw
HTTP body with the subscription secret. Use constant-time comparison.

## Processing

- Delivery is at-least-once.
- Deduplicate messages by `message.id`.
- Deduplicate non-message events by top-level `id`.
- `message.direction` is `in` or `out`.
- `status.*` carries sent, delivered, read, and failed outcomes.
- Optional blocks may be omitted.
- Ignore unknown fields and future event types safely.

## History

History can arrive as `type: "sync.batch"` with up to 100 normalized events in
`events`. Iterate every event. Upsert by `message.id`, preserve
`message.timestamp`, and never auto-reply to `message.source: "history"`.

`message.media_available` updates the existing historical message with the same
ID. It is not a new message.

Subscribe to both `history.*` and `smb_app_state_sync.*` before a Coexistence
history import.

See schemas, retry behavior, scope rules, and examples at
`https://docs.easyhook.dev/webhooks`.
