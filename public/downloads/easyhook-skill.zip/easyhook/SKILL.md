---
name: easyhook
description: Integrate, test, or debug Easyhook messaging APIs, normalized webhooks, WhatsApp onboarding, templates, Flows, consent, n8n, Chatwoot, or MCP. Use whenever an agent must build against Easyhook, review an Easyhook request or payload, troubleshoot an Easyhook error, or migrate a direct Meta integration to Easyhook.
---

# Easyhook

Use Easyhook as the tenant boundary and messaging provider. Prefer the current
public contract at `https://docs.easyhook.dev`; do not infer public fields from
raw Meta payloads or old examples.

## Workflow

1. Identify the organization API key, sender, provider, destination, and
   operation.
2. Read [references/api.md](references/api.md) for sends, onboarding, consent,
   templates, media, or conversation reads.
3. Read [references/webhooks.md](references/webhooks.md) for event ingestion,
   History, signatures, retries, or n8n triggers.
4. Keep the API key server-side. Never send `tenant_id`, Supabase UUIDs, Meta
   tokens, or resources belonging to another organization.
5. Prefer the provider-native `account.id` from Easyhook webhooks as `from`.
   Map it unchanged across WhatsApp, Messenger, Instagram, and Telegram.
   WhatsApp also accepts its connected international business phone number.
6. Preserve Easyhook error codes and response bodies. Do not hide a provider
   failure behind a generic success message.
7. Treat send responses containing a `wamid` as accepted by Meta. Determine
   delivered, read, or failed state from `status.*` webhooks.
8. Add idempotency for retryable application writes and deduplicate webhook
   deliveries.

## Guardrails

- Unknown senders must fail with `phone_not_found`; never fall back to another
  WABA or channel.
- Free-form WhatsApp sends require an open customer-service window.
- Templates outside that window require approved templates and applicable
  consent.
- Reusable media belongs to the API-key organization, not to one WABA. Reuse
  the same `media_name` only on providers compatible with its media type.
- Text and media can be scheduled with `at` on WhatsApp, Messenger, Instagram,
  and Telegram. Mercado Libre supports scheduled text. Email scheduling is not
  part of the current public contract.
- Treat `message.media.url` as private. Use that exact URL server-side with
  `Authorization: Bearer <EASYHOOK_API_KEY>`, or use the n8n
  `Media > Download` operation. Never expose the API key in browser code.
- For website/CRM opt-in, record non-empty evidence with `POST /v1/consent`.
  Easyhook stores evidence; the customer remains responsible for valid consent.
- Check provider capabilities before controls: WhatsApp supports read, typing,
  reply, reaction; Messenger/Instagram support read, typing, reply; Telegram
  supports typing, reply, reaction.
- In n8n, use `Message Action` for cross-channel sends, `Message Control` for
  read/typing/reply/reaction, `Email Only` for Gmail/Outlook/IMAP actions,
  `Onboarding` for hosted connection URLs, `WhatsApp Only` for
  templates/Flows/consent, and
  `Media > Download` for protected incoming files.
- In n8n triggers, explicitly select a provider and one or more compatible
  events. Nothing is preselected. Use the exact names returned by Easyhook.
- History is imported data. Never auto-reply when
  `message.source === "history"`.
- Validate webhook HMAC against the raw body before parsing JSON.
- Respond to webhooks quickly and process durable work asynchronously.
- Redact API keys, webhook secrets, provider tokens, and onboarding codes.

## Source Of Truth

When this skill and the hosted documentation differ, use:

- `https://docs.easyhook.dev/api-reference`
- `https://docs.easyhook.dev/webhooks`
- `https://docs.easyhook.dev/onboarding`

Report the conflict instead of guessing.
