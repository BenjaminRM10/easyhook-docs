---
name: easyhook
description: Integrate, test, audit, or debug Easyhook messaging, Telnyx or WhatsApp Calling, Live Chat, normalized webhooks, WhatsApp onboarding, templates, Flows, consent, scheduling, History, email, Mercado Libre, n8n, Chatwoot, or MCP. Use whenever an agent builds against Easyhook, reviews an Easyhook request or payload, troubleshoots an Easyhook error, or migrates a direct provider integration to Easyhook.
---

# Easyhook

Use Easyhook as the organization boundary and multichannel provider. Prefer the
current public contract at `https://docs.easyhook.dev`; do not infer public
fields from raw provider payloads, database schemas, or old examples.

## Workflow

1. Identify the API key, sender, provider, destination, and operation.
2. Read [references/integration-guide.md](references/integration-guide.md) for
   the implementation workflow and acceptance checklist.
3. Read [references/api.md](references/api.md) for the exact endpoint, request,
   response, error, billing, n8n, Chatwoot, MCP, or provider contract.
4. Read [references/webhooks.md](references/webhooks.md) before consuming an
   event, History batch, status, consent update, or private media URL.
5. Keep the API key server-side. Never send `tenant_id`, Supabase UUIDs, Meta
   tokens, or resources belonging to another organization.
6. Preserve Easyhook error codes and complete response bodies. Do not replace a
   provider failure with a generic success or retry an isolation error against a
   different sender.

## Identity And Isolation

- The API key fixes the organization. `from` must resolve to a sender owned by
  that organization; unknown senders fail instead of falling back.
- Use `POST /v1/messages/text` as the canonical text endpoint. `channel` is
  optional when `from` identifies exactly one compatible connection. If
  Easyhook returns `409 ambiguous_sender`, choose only from
  `available_channels` and retry explicitly; never guess. The old
  `/v1/messages/send`, `/v1/messages/sms`, and `/v1/messages/channel/text`
  paths are compatibility aliases, not choices for new integrations.
- Prefer the exact provider-native `account.id` received in a webhook as
  `from`. Do not add `page_` or `ig_`. WhatsApp also accepts its connected
  international business number.
- For WhatsApp, key a conversation with
  `account.id + ":" + (contact.user_id ?? contact.id)`. A Business-scoped User
  ID (BSUID) is opaque and can replace a phone in contact/message/status fields.
- Never require a WhatsApp contact identifier to contain only digits. Preserve
  `contact.user_id`, `contact.parent_user_id`, `contact.phone`, `contact.username`, and
  `contact.country_code` when supplied.
- Pass a BSUID or parent BSUID unchanged in Easyhook's `to`. Easyhook maps
  opaque identifiers to Meta's dedicated `recipient` field and phones to `to`.
- Subscribe to `user_preferences.*` when marketing preference changes matter;
  the normalized contact can be BSUID-only and can include a parent BSUID.
- One-tap, zero-tap, and copy-code authentication templates still require a
  phone destination and can fail with Meta error `131062` when given a BSUID.

## Messages And Controls

- Free-form WhatsApp sends require an open customer-service window. Approved
  templates and valid consent are required when applicable outside it.
- A send response containing a provider message ID means the provider accepted
  the request. Determine delivered, read, or failed state from `status.*`.
- `message.*` is live inbound traffic only. WhatsApp Business App echoes use
  `smb_message_echo.*`; imported messages use `history.*`. Do not overlap them.
- Send cross-channel reply or URL buttons with `POST /v1/messages/interactive`.
  WhatsApp requires an open service window and accepts either up to three reply
  buttons or one URL button; Messenger, Instagram, and Telegram may mix them.
- Route WhatsApp, Messenger, Instagram, Telegram, and TikTok reply selections by
  `message.quick_reply.payload`, not the visible title.
- TikTok exposes a stable opaque `contact.id` and an opaque
  `message.thread_id` for the conversation; either can be sent as `to`.
  The connected profile must be a TikTok Business Account; preserve
  `tiktok_business_account_required` and ask the owner to change the account
  type before authorizing it again.
  Preserve `tiktok_business_messaging_region_unsupported` when TikTok blocks a
  valid Business Account by registered region; reconnecting does not fix it.
  It does not permit
  business-initiated conversations and limits a business to 10 replies during
  the 48 hours after each user message. Preserve
  `tiktok_messaging_window_closed_or_quota_reached` without blind retries.
- Normalize provider-supported replies, reactions, and edits with
  `message.reply_to.message_id`, `message.reaction`, and `message.edit` across
  WhatsApp, Messenger, and Instagram. Do not infer events a provider did not
  emit; Messenger/Instagram deletion or unsend is not an equivalent webhook.
- Handle WhatsApp `edit`, `revoke`, `system`, button, interactive, reaction,
  unsupported, and media events from their documented structured blocks.
- Check provider capabilities before controls. Unsupported read, typing, reply,
  reaction, quick-reply, or humanized behavior returns an explicit error.
- Humanized presence controls are best-effort; the actual send remains the
  required operation.

## Telefonía

- Model one purchased number as one Telefonía connection with capability flags
  for SMS, MMS, inbound voice, and outbound voice. SMS and voice are event
  modalities, not separate customer connections.
- Use `channel: "sms"` for text messaging and `channel: "phone"` for PSTN
  calls when the number is also connected to WhatsApp. WhatsApp text/calling
  uses `channel: "whatsapp"`.
- In normalized webhooks, the purchased business number is always
  `account.id`. SMS/MMS use `channel: "sms"`; calls use `channel: "voice"`
  with the normalized `call` block.
- Put each future provider adapter behind the shared sender resolver and
  capability contract. Do not add a provider-specific public send path when a
  canonical operation already exists.

## Scheduling And Billing

- Use a stable `Idempotency-Key` when a write can be retried.
- For scheduled sends, provide a `client_reference` of at most 200 characters,
  persist the returned `scheduled_message.id`, and subscribe to `scheduled.*`
  plus `status.*`. Never correlate by recipient, template, or time.
- A locally generated reference without a returned scheduled ID does not prove
  Easyhook received the request. Reconcile with
  `GET /v1/scheduled-messages/{id}`.
- Meta `status.pricing.billable` describes Meta pricing only. Easyhook can bill
  the public outbound API operation even when Meta reports
  `free_customer_service` and `billable: false`.

## Media, Consent, And History

- Reusable media belongs to the API-key organization, not one WABA. Reuse a
  `media_name` only through providers compatible with its type.
- Treat `message.media.url` as private. Download the exact URL server-side with
  the same Easyhook API key, or use n8n `Media > Download`. Never expose the key
  in browser code.
- For website/CRM consent, send auditable evidence with `POST /v1/consent`.
  Easyhook stores it; the customer remains responsible for valid consent.
- Read consent with `GET /v1/consent/status`. Treat `unknown` as no recorded
  choice and subscribe to `consent.updated` for changes.
- Update WhatsApp contact names stored by Easyhook with `PUT /v1/contacts`, an
  explicit `target: "easyhook"`, and a phone or opaque BSUID in `contact`.
  Subscribe to `contact.updated`. This does not modify the WhatsApp Business
  App address book. `target: "provider"` intentionally returns
  `provider_contact_write_unsupported` because Meta exposes no such Cloud API
  write operation.
- History is imported data. Iterate every `sync.batch.events` item, deduplicate
  by `message.id`, preserve `message.timestamp`, and never auto-reply when
  `message.source === "history"`.
- `message.media_available` updates the historical message with the same ID; it
  is not a new customer message.

## Easyhook Live Chat

- Treat the widget publishable key as a widget locator, not as an API key. Use
  exact allowed origins and Turnstile for anonymous session bootstrap.
- Set `data-easyhook-language="auto"` on the installable widget to follow the
  browser language, or use `es`, `en`, or `pt-BR` to force one supported locale.
  The setting also localizes the Turnstile verification frame.
- Create signed application identities server-side with
  `POST /v1/live-chat/identity-tokens`; never let a browser choose or sign its
  own external user ID or roles.
- Browser clients use only their scoped `eh_chat_session_...` token and opaque
  `ehusr_...`/`ehconv_...` IDs. The server infers the sender and enforces
  conversation membership.
- Live Chat supports text, media, stickers, reply, forward, reactions, edits,
  deletion tombstones, read cursors, typing, direct conversations, and groups.
  Use a stable `client_message_id`/`client_action_id` for every retryable write.
- Refresh tokens are rotating and single-use. Do not expose a normal Easyhook
  API key or Supabase credential in the widget or customer frontend.

## Calls

- Number inventory quotes separate the one-time `activation_price`, prorated `initial_period_price`, recurring `monthly_price`, and `due_today` total, plus `initial_period` and `next_renewal_at`. Confirm every expected amount when purchasing. Rent renews in advance on the first UTC day of each month; never treat activation or the initial proration as recurring rent.
- Use the provider-neutral `/v1/calls` and `/v1/call-endpoints` contract for
  Telnyx and WhatsApp Calling. Do not expose carrier or Meta credentials.
- Never proxy audio through Easyhook. Use the returned Telnyx WebRTC JWT or
  WhatsApp SDP so media travels directly between the client and provider.
- Register or heartbeat each answering device with one stable `endpoint_key`.
  Only `available` endpoints seen in the last 90 seconds are routable.
- Claim before answering. Exactly one endpoint wins atomically; declining an
  offer advances the 20-second lease to the next eligible agent.
- For inbound WhatsApp, claim the SDP offer, send `pre-accept` with the SDP
  answer, establish WebRTC, and then send `accept` to avoid clipped audio.
- For outbound Telnyx, register the caller endpoint and pass its `endpoint_id`
  to `POST /v1/calls`; use the returned `webrtc.dial` object with the Telnyx
  SDK. For outbound WhatsApp, create the local SDP offer first and poll
  `/v1/calls/{id}/signaling` for Meta's SDP answer.
- Outbound AI calls use `POST /v1/calls` with `handler: "ai"` and the
  ElevenLabs agent selected for the number's outbound role. It may be the same
  agent used inbound or a different one. Record explicit voice consent
  first with `POST /v1/consent` (`channel: "voice"`); never build an unrestricted
  customer ElevenLabs trunk that bypasses Easyhook wallet and abuse controls.
  The optional bounded scalar `context` is delivered as `X-Easyhook-*` SIP
  headers after the PSTN callee answers. Easyhook enforces one attempt/hour and
  three attempts/24h per tenant/number/contact.
- Before a business-initiated WhatsApp call, use
  `POST /v1/whatsapp/calling/permissions`. Do not infer permission from a text
  reply or retry Meta permission requests aggressively.
- Use `/v1/call-routing?phone_id=...` to configure an ordered policy for one
  tenant-owned number. WhatsApp numbers accept Portal and mobile destinations;
  Telnyx numbers can additionally use a pooled external-phone stage. The same
  number policy governs ordinary inbound calls, AI fallback and AI-requested
  human handoff. External phones in the pool rotate or are selected randomly.
  Never ring every device: Easyhook privately offers one endpoint at a time and
  advances only after decline or lease expiry. `api_only` disables managed
  human destinations.
- For external answering, use `external_agent_id`. SIP endpoints require a
  valid `provider_address`. A Telnyx API endpoint also needs that address to
  carry audio; a WhatsApp API endpoint receives SDP through claim/accept and
  must not be modeled as SIP.
- A call can be rejected before ringing when the wallet cannot reserve its
  maximum permitted duration or when no verified destination tariff exists.
- Always send `max_duration_seconds`. Easyhook enforces it with an authenticated
  backend deadline and releases a reservation when no provider leg starts
  within two minutes; client-side timers are display-only and never a billing
  or abuse-control boundary.

## Integrations

- Easyhook does not appear in Supabase's native phone-provider selector. It is
  installed from the Easyhook portal as Supabase's signed HTTPS Send SMS Hook;
  never tell a user to select a placeholder provider or put an Easyhook API key
  in their Supabase application.
- Supabase Auth is configured in the Easyhook portal per Supabase project. The
  delivery mode is `sms`, `whatsapp`, or `whatsapp_then_sms`; the last mode
  tries WhatsApp first and sends SMS only when that request fails.
- Read [references/supabase-auth.md](references/supabase-auth.md) when building
  or debugging Supabase phone sign-in or phone MFA through Easyhook.
- WhatsApp delivery requires a connected number and a synchronized, approved
  `AUTHENTICATION` template. Do not infer eligibility from an unrelated
  marketing or utility template.
- Continue using `supabase.auth.signInWithOtp({ phone, options: {
  captchaToken } })` and `verifyOtp({ phone, token, type: "sms" })` in the
  application. The verification type remains `sms` for every phone OTP even
  when WhatsApp transported the code.
- Do not claim that `options.channel: "whatsapp"` selects Easyhook's transport.
  Supabase's custom Send SMS Hook does not pass that channel to Easyhook, so
  delivery is a project-level policy. "Both" means WhatsApp with SMS fallback,
  not two messages and not a per-request end-user selector.
- Never persist an OTP in Inbox, customer webhooks, application logs, or
  integration records. One signed Supabase webhook ID must produce at most one
  completed delivery path.

- Use `GET /v1/senders` to discover canonical provider account IDs and
  current normalized health. Use `GET /v1/senders/{account_id}/health` for a
  single sender and subscribe to `channel.health_changed` for transition-only
  notifications. Prompt reconnection only for `reauthorization_required`;
  treat `unreachable` as potentially temporary.
- Use `DELETE /v1/senders/{account_id}` to disconnect a tenant-owned channel
  without exposing internal Easyhook IDs or the portal. The delete is
  idempotent and requires `onboarding:write`; existing `messages:write` keys
  remain compatible.
- Subscribe to `onboarding.*` for hosted connection lifecycle. A completed
  event is durably retried and includes `onboarding.connection.account_id`,
  provider, display name, and the connected channel reference when applicable.
- For Messenger onboarding, accept only Pages included in Meta's
  asset-specific `pages_messaging` targets. `meta_page_access_unavailable`
  means Meta did not expose a usable messaging credential for the selected
  Page; surface the diagnostic and require a reconnect instead of selecting a
  different granted Page.
- In n8n, use `Message Action` for cross-channel sends, `Message Control` for
  read/typing/reply/reaction, `Email Only` for mailbox actions, `Onboarding` for
  hosted connections, `WhatsApp Only` for templates/Flows/consent, and `Media >
  Download` for protected files.
- In n8n triggers, explicitly select compatible provider, event, and scope
  values from Easyhook. Nothing is preselected.
- Change an existing webhook's event filters with
  `PATCH /v1/webhooks/{id}`. This preserves its URL, secret, authentication,
  providers, scope, and delivery history.
- In Chatwoot, Easyhook is the transport for supported channels, including
  TikTok Business Messaging. Preserve channel boundaries and do
  not treat Chatwoot as the source of provider credentials.
- In MCP, keep the sender and API key in process environment variables and
  restrict tools to named, described contacts.
- Do not expose sender disconnection as an MCP tool. It is a destructive tenant
  administration operation; call `DELETE /v1/senders/{account_id}` only from an
  explicitly approved management flow.

## Webhook Safety

- Validate HMAC against the exact raw body before parsing JSON.
- Respond with `2xx` quickly and process durable work asynchronously.
- Delivery is at-least-once. Deduplicate messages by `message.id` and other
  events by top-level `id` unless the event contract specifies a stronger key.
- Ignore unknown optional fields and future enum values safely.
- Redact API keys, webhook secrets, provider tokens, onboarding codes, and
  private media URLs from logs and prompts.

## Source Of Truth

When this skill and hosted documentation differ, use:

- `https://docs.easyhook.dev/api-reference`
- `https://docs.easyhook.dev/webhooks`
- `https://docs.easyhook.dev/ai-agents`
- `https://docs.easyhook.dev/onboarding`

Report the conflict instead of guessing.
