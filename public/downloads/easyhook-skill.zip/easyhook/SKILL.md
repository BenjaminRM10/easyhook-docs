---
name: easyhook
description: Integrate, test, audit, or debug Easyhook messaging and Google Business Profile review APIs, normalized webhooks, WhatsApp onboarding, templates, Flows, consent, scheduling, History, email, Mercado Libre, n8n, Chatwoot, or MCP. Use whenever an agent builds against Easyhook, reviews an Easyhook request or payload, troubleshoots an Easyhook error, or migrates a direct provider integration to Easyhook.
---

# Easyhook

Use Easyhook as the organization boundary and multichannel provider. Prefer the
current public contract at `https://docs.easyhook.dev`; do not infer public
fields from raw provider payloads, database schemas, or old examples.

## Workflow

1. Identify the API key, sender, provider, destination, and operation.
2. Read [references/integration-guide.md](references/integration-guide.md) for
   the implementation workflow and acceptance checklist.
3. Read [references/api.md](references/api.md) for the exact endpoint, request,
   response, error, billing, n8n, Chatwoot, MCP, or provider contract.
4. Read [references/webhooks.md](references/webhooks.md) before consuming an
   event, History batch, status, consent update, review, or private media URL.
5. Keep the API key server-side. Never send `tenant_id`, Supabase UUIDs, Meta
   tokens, or resources belonging to another organization.
6. Preserve Easyhook error codes and complete response bodies. Do not replace a
   provider failure with a generic success or retry an isolation error against a
   different sender.

## Identity And Isolation

- The API key fixes the organization. `from` must resolve to a sender owned by
  that organization; unknown senders fail instead of falling back.
- Prefer the exact provider-native `account.id` received in a webhook as
  `from`. Do not add `page_` or `ig_`. WhatsApp also accepts its connected
  international business number.
- For WhatsApp, key a conversation with
  `account.id + ":" + (contact.user_id ?? contact.id)`. A Business-scoped User
  ID (BSUID) is opaque and can replace a phone in contact/message/status fields.
- Never require a WhatsApp contact identifier to contain only digits. Preserve
  `contact.user_id`, `contact.phone`, `contact.username`, and
  `contact.country_code` when supplied.
- One-tap, zero-tap, and copy-code authentication templates still require a
  phone destination and can fail with Meta error `131062` when given a BSUID.

## Messages And Controls

- Free-form WhatsApp sends require an open customer-service window. Approved
  templates and valid consent are required when applicable outside it.
- A send response containing a provider message ID means the provider accepted
  the request. Determine delivered, read, or failed state from `status.*`.
- `message.*` is live inbound traffic only. WhatsApp Business App echoes use
  `smb_message_echo.*`; imported messages use `history.*`. Do not overlap them.
- Route Messenger/Instagram quick replies by
  `message.quick_reply.payload`, not the visible title.
- Treat Messenger, Instagram Direct, Facebook comments, and Instagram comments
  as independent connections. Public comments use providers
  `facebook_comments` or `instagram_comments`, events `comment.*`, and the
  public comments API; never send them through a DM endpoint.
- Handle WhatsApp `edit`, `revoke`, `system`, button, interactive, reaction,
  unsupported, and media events from their documented structured blocks.
- Check provider capabilities before controls. Unsupported read, typing, reply,
  reaction, quick-reply, or humanized behavior returns an explicit error.
- Humanized presence controls are best-effort; the actual send remains the
  required operation.

## Scheduling And Billing

- Use a stable `Idempotency-Key` when a write can be retried.
- For scheduled sends, provide a `client_reference` of at most 200 characters,
  persist the returned `scheduled_message.id`, and subscribe to `scheduled.*`
  plus `status.*`. Never correlate by recipient, template, or time.
- A locally generated reference without a returned scheduled ID does not prove
  Easyhook received the request. Reconcile with
  `GET /v1/scheduled-messages/{id}`.
- Meta `status.pricing.billable` describes Meta pricing only. Easyhook can bill
  the public outbound API operation even when Meta reports
  `free_customer_service` and `billable: false`.

## Media, Consent, And History

- Reusable media belongs to the API-key organization, not one WABA. Reuse a
  `media_name` only through providers compatible with its type.
- Treat `message.media.url` as private. Download the exact URL server-side with
  the same Easyhook API key, or use n8n `Media > Download`. Never expose the key
  in browser code.
- For website/CRM consent, send auditable evidence with `POST /v1/consent`.
  Easyhook stores it; the customer remains responsible for valid consent.
- Read consent with `GET /v1/consent/status`. Treat `unknown` as no recorded
  choice and subscribe to `consent.updated` for changes.
- History is imported data. Iterate every `sync.batch.events` item, deduplicate
  by `message.id`, preserve `message.timestamp`, and never auto-reply when
  `message.source === "history"`.
- `message.media_available` updates the historical message with the same ID; it
  is not a new customer message.

## Integrations

- In n8n, use `Message Action` for cross-channel sends, `Message Control` for
  read/typing/reply/reaction, `Email Only` for mailbox actions, `Onboarding` for
  hosted connections, `WhatsApp Only` for templates/Flows/consent, and `Media >
  Download` for protected files.
- In n8n triggers, explicitly select compatible provider, event, and scope
  values from Easyhook. Nothing is preselected.
- Change an existing webhook's event filters with
  `PATCH /v1/webhooks/{id}`. This preserves its URL, secret, authentication,
  providers, scope, and delivery history.
- In Chatwoot, Easyhook is the transport. Preserve channel boundaries and do
  not treat Chatwoot as the source of provider credentials.
- In MCP, keep the sender and API key in process environment variables and
  restrict tools to named, described contacts.

## Webhook Safety

- Validate HMAC against the exact raw body before parsing JSON.
- Respond with `2xx` quickly and process durable work asynchronously.
- Delivery is at-least-once. Deduplicate messages by `message.id` and other
  events by top-level `id` unless the event contract specifies a stronger key.
- Ignore unknown optional fields and future enum values safely.
- Redact API keys, webhook secrets, provider tokens, onboarding codes, and
  private media URLs from logs and prompts.

## Source Of Truth

When this skill and hosted documentation differ, use:

- `https://docs.easyhook.dev/api-reference`
- `https://docs.easyhook.dev/webhooks`
- `https://docs.easyhook.dev/ai-agents`
- `https://docs.easyhook.dev/onboarding`

Report the conflict instead of guessing.
