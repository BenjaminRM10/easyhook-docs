---
name: easyhook
description: Integrate, test, or debug Easyhook messaging APIs, normalized webhooks, WhatsApp onboarding, templates, Flows, consent, n8n, Chatwoot, or MCP. Use whenever an agent must build against Easyhook, review an Easyhook request or payload, troubleshoot an Easyhook error, or migrate a direct Meta integration to Easyhook.
---

# Easyhook

Use Easyhook as the tenant boundary and messaging provider. Prefer the current
public contract at `https://docs.easyhook.dev`; do not infer public fields from
raw Meta payloads or old examples.

## Workflow

1. Identify the organization API key, sender, provider, destination, and
   operation.
2. Read [references/api.md](references/api.md) for sends, onboarding, consent,
   templates, media, or conversation reads.
3. Read [references/webhooks.md](references/webhooks.md) for event ingestion,
   History, signatures, retries, or n8n triggers.
4. Keep the API key server-side. Never send `tenant_id`, Supabase UUIDs, Meta
   tokens, or resources belonging to another organization.
5. Use international phone numbers. Easyhook resolves the WABA and Phone Number
   ID from a tenant-owned `from`.
6. Preserve Easyhook error codes and response bodies. Do not hide a provider
   failure behind a generic success message.
7. Treat send responses containing a `wamid` as accepted by Meta. Determine
   delivered, read, or failed state from `status.*` webhooks.
8. Add idempotency for retryable application writes and deduplicate webhook
   deliveries.

## Guardrails

- Unknown senders must fail with `phone_not_found`; never fall back to another
  WABA or channel.
- Free-form WhatsApp sends require an open customer-service window.
- Templates outside that window require approved templates and applicable
  consent.
- History is imported data. Never auto-reply when
  `message.source === "history"`.
- Validate webhook HMAC against the raw body before parsing JSON.
- Respond to webhooks quickly and process durable work asynchronously.
- Redact API keys, webhook secrets, provider tokens, and onboarding codes.

## Source Of Truth

When this skill and the hosted documentation differ, use:

- `https://docs.easyhook.dev/api-reference`
- `https://docs.easyhook.dev/webhooks`
- `https://docs.easyhook.dev/onboarding`

Report the conflict instead of guessing.
